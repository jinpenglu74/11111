#!/usr/bin/env python3
from pathlib import Path
import re, shutil, sys

root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else None
if not root or not (root/'shared/constants.ts').exists():
    raise SystemExit('usage: apply_v2_core_patch.py <multi-ai-chat-desktop-v1.9.6-source>')
patch=Path(__file__).resolve().parent

def replace(path, old, new, count=-1):
    p=root/path
    s=p.read_text(encoding='utf-8')
    if old not in s:
        raise SystemExit(f'anchor not found in {path}: {old[:120]!r}')
    p.write_text(s.replace(old,new,count), encoding='utf-8')

def replace_exact_count(path, old, new, expected_count):
    p=root/path
    s=p.read_text(encoding='utf-8')
    actual=s.count(old)
    if actual != expected_count:
        raise SystemExit(f'anchor count mismatch in {path}: expected {expected_count}, got {actual}: {old[:120]!r}')
    p.write_text(s.replace(old,new), encoding='utf-8')

def copy(rel):
    src=patch/rel; dst=root/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)

# --- Provider: reuse frozen fifth internal id (`meta`) but make the bundled scope truly DeepSeek. ---
copy(Path('adapters/meta.json'))
# Adapter verifier regression changes are applied by apply_v2_regression_patch.py.


copy(Path('src/workflow/rewritePipeline.ts'))
copy(Path('src/ui/RewriteDubbingPanel.tsx'))
copy(Path('src/i18n/zh-CN.ts'))
copy(Path('src/assets/themes/ai-sister/deepseek.svg'))
copy(Path('src-tauri/src/velovoice.rs'))

replace(Path('shared/constants.ts'),
"  meta: {\n    name: 'Meta AI',\n    url: 'https://www.meta.ai',\n    loginUrl: 'https://www.meta.ai',\n    color: '#0668e1',\n  },",
"  meta: {\n    name: 'DeepSeek',\n    url: 'https://chat.deepseek.com',\n    loginUrl: 'https://chat.deepseek.com',\n    color: '#4d6bfe',\n  },")
replace(Path('src/ui/AiSisterTheme.tsx'), "import metaAvatarUrl from '../assets/themes/ai-sister/meta.webp';", "import deepSeekAvatarUrl from '../assets/themes/ai-sister/deepseek.svg';")
replace(Path('src/ui/AiSisterTheme.tsx'), '  meta: metaAvatarUrl,', '  meta: deepSeekAvatarUrl,')

# --- Native settings layer: add zh-CN support while preserving upstream provider/default behavior. ---
replace(Path('src-tauri/src/settings.rs'), 'const LANGUAGES: &[&str] = &["system", "en", "zh-TW", "ja", "de"];', 'const LANGUAGES: &[&str] = &["system", "en", "zh-CN", "zh-TW", "ja", "de"];')
replace(Path('src-tauri/src/settings.rs'), 'const RESPONSE_LANGUAGES: &[&str] = &["auto", "en", "zh-TW", "ja", "de"];', 'const RESPONSE_LANGUAGES: &[&str] = &["auto", "en", "zh-CN", "zh-TW", "ja", "de"];')
replace(Path('src-tauri/src/settings.rs'), 'for language in ["auto", "en", "zh-TW", "ja", "de"] {', 'for language in ["auto", "en", "zh-CN", "zh-TW", "ja", "de"] {')


replace(Path('src/ui/AiSisterTheme.tsx'), "const META_ACCENT: ProviderAccent = { solid: '#1877f2', shadow: 'rgba(24, 119, 242, 0.5)' };", "const DEEPSEEK_ACCENT: ProviderAccent = { solid: '#4d6bfe', shadow: 'rgba(77, 107, 254, 0.5)' };")
replace(Path('src/ui/AiSisterTheme.tsx'), "  meta: META_ACCENT,", "  meta: DEEPSEEK_ACCENT,")

# --- Simplified Chinese is a first-class locale; system-language behavior remains the upstream default. ---
replace(Path('src/i18n/resolve.ts'),
"export type LanguageSetting = 'system' | 'en' | 'zh-TW' | 'ja' | 'de';",
"export type LanguageSetting = 'system' | 'en' | 'zh-CN' | 'zh-TW' | 'ja' | 'de';")
replace(Path('src/i18n/resolve.ts'),
"export const LANGUAGE_SETTINGS = ['system', 'en', 'zh-TW', 'ja', 'de'] as const satisfies readonly LanguageSetting[];\nexport const RESPONSE_LANGUAGE_SETTINGS = ['auto', 'en', 'zh-TW', 'ja', 'de'] as const satisfies readonly ResponseLanguageSetting[];",
"export const LANGUAGE_SETTINGS = ['system', 'en', 'zh-CN', 'zh-TW', 'ja', 'de'] as const satisfies readonly LanguageSetting[];\nexport const RESPONSE_LANGUAGE_SETTINGS = ['auto', 'en', 'zh-CN', 'zh-TW', 'ja', 'de'] as const satisfies readonly ResponseLanguageSetting[];")
replace(Path('src/i18n/resolve.ts'),
"  if (normalized === 'zh' || normalized.startsWith('zh-')) return 'zh-TW';",
"  if (normalized === 'zh' || normalized === 'zh-cn' || normalized === 'zh-sg' || normalized.startsWith('zh-hans')) return 'zh-CN';\n  if (normalized === 'zh-tw' || normalized === 'zh-hk' || normalized === 'zh-mo' || normalized.startsWith('zh-hant')) return 'zh-TW';")
replace(Path('src/i18n/t.ts'), "import { zhTW } from './zh-TW';", "import { zhCN } from './zh-CN';\nimport { zhTW } from './zh-TW';")
replace(Path('src/i18n/t.ts'), "  en,\n  'zh-TW': zhTW,", "  en,\n  'zh-CN': zhCN,\n  'zh-TW': zhTW,")
replace(Path('src/ui/SettingsModal.tsx'),
"                  <option value=\"en\">{t('settings.language.en')}</option>\n                  <option value=\"zh-TW\">{t('settings.language.zhTW')}</option>",
"                  <option value=\"en\">{t('settings.language.en')}</option>\n                  <option value=\"zh-CN\">简体中文</option>\n                  <option value=\"zh-TW\">{t('settings.language.zhTW')}</option>", 1)
# Same option block appears once more for response language.
replace(Path('src/ui/SettingsModal.tsx'),
"                  <option value=\"en\">{t('settings.language.en')}</option>\n                  <option value=\"zh-TW\">{t('settings.language.zhTW')}</option>",
"                  <option value=\"en\">{t('settings.language.en')}</option>\n                  <option value=\"zh-CN\">简体中文</option>\n                  <option value=\"zh-TW\">{t('settings.language.zhTW')}</option>", 1)
replace(Path('src/workflow/responseLanguage.ts'),
"  en: 'English (en)',\n  'zh-TW': 'Traditional Chinese (zh-TW)',",
"  en: 'English (en)',\n  'zh-CN': 'Simplified Chinese (zh-CN)',\n  'zh-TW': 'Traditional Chinese (zh-TW)',")
replace(Path('src/workflow/responseLanguage.ts'),
"const LOCALES = new Set<Locale>(['en', 'zh-TW', 'ja', 'de']);",
"const LOCALES = new Set<Locale>(['en', 'zh-CN', 'zh-TW', 'ja', 'de']);")
replace(Path('src/workflow/graph/registries.ts'),
"  const conjunction = locale === 'zh-TW' ? '與' : locale === 'de' ? 'und' : 'and';",
"  const conjunction = locale === 'zh-CN' ? '和' : locale === 'zh-TW' ? '與' : locale === 'de' ? 'und' : 'and';")
replace(Path('src/workflow/graph/registries.ts'),
"  const separator = locale === 'zh-TW' ? '、' : ', ';",
"  const separator = locale === 'zh-CN' || locale === 'zh-TW' ? '、' : ', ';")

translations={
 'src/i18n/en.ts': 'Complete DeepSeek sign-in in this window. The rewrite workflow uses this embedded DeepSeek session.',
 'src/i18n/zh-TW.ts': '請在此視窗完成 DeepSeek 登入。改寫流程會直接使用這個內嵌 DeepSeek 工作階段。',
 'src/i18n/ja.ts': 'このウィンドウで DeepSeek のログインを完了してください。改稿ワークフローはこの埋め込み DeepSeek セッションを直接使用します。',
 'src/i18n/de.ts': 'Schließe die DeepSeek-Anmeldung in diesem Fenster ab. Der Rewrite-Workflow verwendet diese eingebettete DeepSeek-Sitzung direkt.',
}
for rel,text in translations.items():
    p=root/rel; s=p.read_text(encoding='utf-8')
    s2=re.sub(r"('provider\.metaLoginGuidance':\s*)'[^']*'", lambda m:m.group(1)+repr(text), s, count=1)
    if s2==s: raise SystemExit(f'i18n anchor not found: {rel}')
    p.write_text(s2,encoding='utf-8')

# --- Keep upstream i18n regression tests aligned with the new first-class zh-CN locale. ---
replace(Path('src/__tests__/i18n.test.ts'),
"import { zhTW } from '../i18n/zh-TW';",
"import { zhCN } from '../i18n/zh-CN';\nimport { zhTW } from '../i18n/zh-TW';")
replace(Path('src/__tests__/i18n.test.ts'),
"const dictionaries = { en, 'zh-TW': zhTW, ja, de } as const;",
"const dictionaries = { en, 'zh-CN': zhCN, 'zh-TW': zhTW, ja, de } as const;")
replace(Path('src/__tests__/i18n.test.ts'),
"expect(LANGUAGE_SETTINGS).toEqual(['system', 'en', 'zh-TW', 'ja', 'de']);",
"expect(LANGUAGE_SETTINGS).toEqual(['system', 'en', 'zh-CN', 'zh-TW', 'ja', 'de']);")
replace(Path('src/__tests__/i18n.test.ts'),
"expect(RESPONSE_LANGUAGE_SETTINGS).toEqual(['auto', 'en', 'zh-TW', 'ja', 'de']);",
"expect(RESPONSE_LANGUAGE_SETTINGS).toEqual(['auto', 'en', 'zh-CN', 'zh-TW', 'ja', 'de']);")
replace(Path('src/__tests__/i18n.test.ts'),
"expect(resolveLocale('system', ['zh'])).toBe('zh-TW');\n    expect(resolveLocale('system', ['zh-CN'])).toBe('zh-TW');",
"expect(resolveLocale('system', ['zh'])).toBe('zh-CN');\n    expect(resolveLocale('system', ['zh-CN'])).toBe('zh-CN');\n    expect(resolveLocale('system', ['zh-SG'])).toBe('zh-CN');")
replace(Path('src/__tests__/i18n.test.ts'),
"expect(resolveLocale('zh-TW', ['en-US'])).toBe('zh-TW');",
"expect(resolveLocale('zh-CN', ['en-US'])).toBe('zh-CN');\n    expect(resolveLocale('zh-TW', ['en-US'])).toBe('zh-TW');")

# --- Expose the V2 task center above the mature Multi-AI workspace. ---
replace(Path('src/App.tsx'),
"import { PresetCatalog } from './ui/PresetCatalog';",
"import { PresetCatalog } from './ui/PresetCatalog';\nimport { RewriteDubbingPanel } from './ui/RewriteDubbingPanel';")
replace(Path('src/App.tsx'), '  const [isProcessing, setIsProcessing] = useState(false);', '  const [isProcessing, setIsProcessing] = useState(false);\n  const [rewriteDubbingRunning, setRewriteDubbingRunning] = useState(false);')
replace(Path('src/App.tsx'),
"              <AiSisterEnsembleCard />\n              <PresetCatalog",
"              <RewriteDubbingPanel disabled={isProcessing} onRunningChange={setRewriteDubbingRunning} />\n              <AiSisterEnsembleCard />\n              <PresetCatalog")

replace(Path('src/App.tsx'), '  const send = async (trimmed: string): Promise<boolean> => {\n    if (!trimmed) return false;', '  const send = async (trimmed: string): Promise<boolean> => {\n    if (rewriteDubbingRunning) return false;\n    if (!trimmed) return false;')
replace(Path('src/App.tsx'), '            disabled={isProcessing}\n            locale={locale}', '            disabled={isProcessing || rewriteDubbingRunning}\n            locale={locale}')
replace(Path('src/App.tsx'), '              disabled={noSendableProviders}\n              sendBlocked={modeSendBlocked}', '              disabled={noSendableProviders || rewriteDubbingRunning}\n              sendBlocked={modeSendBlocked || rewriteDubbingRunning}')
replace(Path('src/App.tsx'), '        providerSelectionDisabled={isProcessing}', '        providerSelectionDisabled={isProcessing || rewriteDubbingRunning}')
# --- Main control pane -> local-only VeloVoice sidecar commands. ---
replace(Path('src/host/index.ts'),
"  settings: {\n    get: (): Promise<unknown> => invoke('settings_get'),",
"  velovoice: {\n    start: (): Promise<{ ready: boolean; running: boolean; outputFolder?: string; clientType?: string }> => invoke('velovoice_start'),\n    status: (): Promise<{ ready: boolean; running: boolean; outputFolder?: string; clientType?: string }> => invoke('velovoice_status'),\n    show: (): Promise<void> => invoke('velovoice_show'),\n    dub: (baseName: string, text: string): Promise<{ outputFolder: string; files: string[] }> =>\n      invoke('velovoice_dub', { baseName, text }),\n  },\n  settings: {\n    get: (): Promise<unknown> => invoke('settings_get'),")

replace(Path('src-tauri/src/lib.rs'), "mod webviews;", "mod webviews;\nmod velovoice;")
replace(Path('src-tauri/src/lib.rs'),
"    tauri::Builder::default()\n        .plugin(tauri_plugin_dialog::init())",
"    tauri::Builder::default()\n        .manage(velovoice::VeloVoiceRuntime::default())\n        .plugin(tauri_plugin_dialog::init())")
replace(Path('src-tauri/src/lib.rs'),
"            session_checkpoint::session_checkpoint_clear\n        ])",
"            session_checkpoint::session_checkpoint_clear,\n            velovoice::velovoice_start,\n            velovoice::velovoice_status,\n            velovoice::velovoice_show,\n            velovoice::velovoice_dub\n        ])")
replace(Path('src-tauri/Cargo.toml'), 'name = \"multi-ai-chat-desktop\"', 'name = \"rewrite-dubbing-v2\"', 1)
replace(Path('src-tauri/Cargo.toml'), 'version = \"0.0.0\"', 'version = \"2.0.0\"', 1)
replace(Path('src-tauri/Cargo.toml'),
"thiserror = \"2.0.9\"",
"thiserror = \"2.0.9\"\nrand = \"0.8.5\"")

# Product identity + complete V2 resources (Runtime + VeloVoice sidecar + native dependencies).
replace(Path('src-tauri/tauri.conf.json'), '"productName": "Multi-AI Chat Desktop"', '"productName": "改写配音软件"')
replace(Path('src-tauri/tauri.conf.json'), '"identifier": "com.tedh.multiaichat"', '"identifier": "com.ezq.rewritedubbing"')
replace(Path('src-tauri/tauri.conf.json'), '"title": "Multi-AI Chat Desktop"', '"title": "改写配音软件"')
replace(Path('src-tauri/tauri.conf.json'),
'    "active": true,\n    "icon": [',
'    "active": true,\n    "resources": {"../v2-resources/": ""},\n    "icon": [')

# V2 identity. Release workflow may still overwrite version for packaging, which is fine.
replace(Path('package.json'), '"name": "multi-ai-chat-desktop",', '"name": "rewrite-dubbing-v2",')
replace(Path('package.json'), '"version": "0.0.0",', '"version": "2.0.0",')
replace(Path('src-tauri/tauri.conf.json'), '"version": "0.0.0"', '"version": "2.0.0"')

print('V2_CORE_PATCH_APPLIED')
