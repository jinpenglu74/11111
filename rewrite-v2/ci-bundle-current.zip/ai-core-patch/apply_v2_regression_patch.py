#!/usr/bin/env python3
from pathlib import Path
import re, sys

root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else None
if not root or not (root/'shared/constants.ts').exists():
    raise SystemExit('usage: apply_v2_regression_patch.py <patched-multi-ai-chat-source>')

def replace(rel, old, new, count=-1):
    p=root/rel
    s=p.read_text(encoding='utf-8')
    if old not in s:
        raise SystemExit(f'anchor not found in {rel}: {old[:120]!r}')
    p.write_text(s.replace(old,new,count),encoding='utf-8')

def regex_replace(rel, pattern, replacement, count=0):
    p=root/rel
    s=p.read_text(encoding='utf-8')
    out,n=re.subn(pattern,replacement,s,count=count,flags=re.S)
    if n == 0:
        raise SystemExit(f'regex anchor not found in {rel}: {pattern[:120]!r}')
    p.write_text(out,encoding='utf-8')
    return n

# Keep all mature upstream provider defaults/roles/slot assignments unchanged.
# Only user-visible copy for the frozen fifth internal provider id (`meta`) changes to DeepSeek.
replace(Path('src/__tests__/FocusPaneHeader.test.tsx'),
        "      expect(html).toContain('Complete guest, email/mobile, or Facebook/Instagram sign-in in this window');\n      expect(html).toContain('A login in another browser cannot return here');",
        "      expect(html).toContain('Complete DeepSeek sign-in in this window');\n      expect(html).toContain('The rewrite workflow uses this embedded DeepSeek session');")
replace(Path('src/__tests__/FocusPaneHeader.test.tsx'),
        "expect(renderMeta('logged_in')).not.toContain('Use guest chat or email/mobile login');",
        "expect(renderMeta('logged_in')).not.toContain('Complete DeepSeek sign-in in this window');")
replace(Path('src/__tests__/FocusPaneHeader.test.tsx'),
        "expect(renderHeader('logged_out')).not.toContain('Use guest chat or email/mobile login');",
        "expect(renderHeader('logged_out')).not.toContain('Complete DeepSeek sign-in in this window');")
replace(Path('src/__tests__/FocusPaneHeader.test.tsx'),
        "for (const language of ['en', 'zh-TW', 'ja', 'de'] as const)",
        "for (const language of ['en', 'zh-CN', 'zh-TW', 'ja', 'de'] as const)")
replace(Path('src/__tests__/FocusPaneHeader.test.tsx'),
        "    expect(html).not.toContain('aria-label=\"Meta AI:');",
        "    expect(html).not.toContain('aria-label=\"DeepSeek:');")
replace(Path('src/__tests__/FocusPaneHeader.test.tsx'),
        "  it('shows Meta AI only when it replaces the selected standby provider', () => {",
        "  it('shows DeepSeek only when it replaces the selected standby provider', () => {")
replace(Path('src/__tests__/FocusPaneHeader.test.tsx'),
        "    expect(html).toContain('aria-label=\"Meta AI: Ready\"');",
        "    expect(html).toContain('aria-label=\"DeepSeek: Ready\"');")

# Adapter verifier: internal id `meta` now bundles DeepSeek and uses Enter as the send strategy.
regex_replace(Path('scripts/check-adapters.mjs'), r"  meta: \{\n.*?\n  \},\n\};",
"""  meta: {
    schemaVersion: 1,
    adapterVersion: 100,
    urls: {
      app: 'https://chat.deepseek.com',
      login: 'https://chat.deepseek.com',
      match: ['chat.deepseek.com/*'],
      ssoMatch: [],
    },
    inputStrategy: 'default',
    sendStrategy: 'enter',
    doneDelayMs: 3500,
    chunkDebounceMs: 800,
    inputSelectors: ['textarea#chat-input', '#chat-input textarea', 'textarea[placeholder="给 DeepSeek 发送消息 "]', 'textarea[placeholder*="DeepSeek"]', 'textarea'],
    sendButtonSelectors: ['button[aria-label*="Send"]', 'button[aria-label*="发送"]', 'div[role="button"]'],
    responseSelectors: ['div.ds-assistant-message-main-content', '.ds-assistant-message-main-content'],
    loginDetectors: ['textarea#chat-input', '#chat-input textarea', 'textarea[placeholder*="DeepSeek"]'],
    loggedOutDetectors: [],
    thinkingDetectors: ['.ds-message-loading', 'span.ds-message-loading'],
    stopButtonSelectors: ['button[aria-label*="Stop"]', 'button[aria-label*="停止"]'],
  },
};""", count=1)
replace(Path('scripts/check-adapters.mjs'),
        "  assertEqual(adapter.sendStrategy, 'click', `${provider}.sendStrategy`);",
        "  assertEqual(adapter.sendStrategy, spec.sendStrategy ?? 'click', `${provider}.sendStrategy`);")
regex_replace(Path('scripts/check-adapters.mjs'),
               r"// Meta app surface stays on meta\.ai\..*?assertEqual\(\n  metaAdapter\.timing,\n  \{ doneDelayMs: 5000, chunkDebounceMs: 600, statusIntervalMs: 10000, backupPollMs: 3000 \},\n  'meta\.initialSeed\.timing',\n\);",
"""// The frozen internal provider id `meta` is deliberately reused as the DeepSeek compatibility slot.
const metaAdapter = JSON.parse(await readFile(path.join(adapterDir, 'meta.json'), 'utf8'));
assertEqual(metaAdapter.displayName, 'DeepSeek', 'meta.deepSeek.displayName');
assertEqual(metaAdapter.urls.match, ['chat.deepseek.com/*'], 'meta.deepSeek.appScopes');
assertEqual(metaAdapter.urls.ssoMatch, [], 'meta.deepSeek.ssoScopes');
assertEqual(metaAdapter.responseSelectors, ['div.ds-assistant-message-main-content', '.ds-assistant-message-main-content'], 'meta.deepSeek.responseSelectors');
assertEqual(metaAdapter.thinkingDetectors, ['.ds-message-loading', 'span.ds-message-loading'], 'meta.deepSeek.thinkingDetectors');
assertEqual(metaAdapter.timing, { doneDelayMs: 3500, chunkDebounceMs: 800, statusIntervalMs: 10000, backupPollMs: 3000 }, 'meta.deepSeek.timing');""", count=1)

# Rust navigation/security unit tests for the DeepSeek compatibility scope.
replace(Path('src-tauri/src/adapters.rs'),
"""            (
                "meta",
                "https://www.meta.ai",
                "https://www.meta.ai/chat/123",
                "http://www.meta.ai/chat/123",
            ),""",
"""            (
                "meta",
                "https://chat.deepseek.com",
                "https://chat.deepseek.com/a/chat/s/123",
                "http://chat.deepseek.com/a/chat/s/123",
            ),""")
regex_replace(Path('src-tauri/src/adapters.rs'),
               r"    #\[test\]\n    fn meta_initial_seed_is_registered_and_keeps_navigation_narrow\(\) \{.*?\n    \}\n\n    #\[test\]\n    fn source_url_defaults_to_repo",
"""    #[test]
    fn deepseek_compatibility_slot_is_registered_and_keeps_navigation_narrow() {
        let meta = adapters().get("meta").expect("DeepSeek compatibility adapter is bundled");
        assert_eq!(meta.display_name, "DeepSeek");
        assert_eq!(meta.adapter_version, 100);
        assert_eq!(meta.urls.app, "https://chat.deepseek.com");
        assert_eq!(meta.urls.login, "https://chat.deepseek.com");
        assert_eq!(meta.urls.match_patterns, vec!["chat.deepseek.com/*".to_string()]);
        assert!(meta.urls.sso_match.is_empty());
        let hosts = app_hosts_for_provider("meta").unwrap();
        assert_eq!(hosts, vec!["chat.deepseek.com".to_string()]);

        for value in [
            "https://chat.deepseek.com/",
            "https://chat.deepseek.com/a/chat/s/123",
        ] {
            let url = tauri::Url::parse(value).unwrap();
            assert!(url_allowed_for_provider("meta", &url).unwrap(), "{value}");
        }

        for value in [
            "https://chat.deepseek.com.evil.net/",
            "http://chat.deepseek.com/",
            "https://chat.deepseek.com:8443/",
            "https://user:pass@chat.deepseek.com/",
        ] {
            let url = tauri::Url::parse(value).unwrap();
            assert!(!url_allowed_for_provider("meta", &url).unwrap(), "{value}");
        }
    }

    #[test]
    fn source_url_defaults_to_repo""", count=1)

print('V2_REGRESSION_PATCH_APPLIED')
