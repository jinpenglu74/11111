use rand::{rngs::OsRng, RngCore};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::net::{TcpStream, ToSocketAddrs};
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::sync::Mutex;
use std::time::Duration;
use tauri::{AppHandle, Manager, State};

#[cfg(windows)]
use std::os::windows::process::CommandExt;

#[cfg(windows)]
const CREATE_NO_WINDOW: u32 = 0x0800_0000;

#[derive(Default)]
pub struct VeloVoiceRuntime {
    inner: Mutex<VeloVoiceState>,
}

#[derive(Default)]
struct VeloVoiceState {
    child: Option<Child>,
    token: String,
    port: u16,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VeloVoiceStatus {
    pub ready: bool,
    pub running: bool,
    pub output_folder: Option<String>,
    pub client_type: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VeloVoiceDubResult {
    pub output_folder: String,
    pub files: Vec<String>,
}

#[tauri::command]
pub async fn velovoice_start(
    app: AppHandle,
    runtime: State<'_, VeloVoiceRuntime>,
) -> Result<VeloVoiceStatus, String> {
    ensure_started(&app, &runtime)?;
    velovoice_status(app, runtime).await
}

#[tauri::command]
pub async fn velovoice_show(
    app: AppHandle,
    runtime: State<'_, VeloVoiceRuntime>,
) -> Result<(), String> {
    let endpoint = ensure_started(&app, &runtime)?;
    tokio::task::spawn_blocking(move || request(endpoint, "show", json!({})))
        .await
        .map_err(|error| error.to_string())??;
    Ok(())
}

#[tauri::command]
pub async fn velovoice_status(
    app: AppHandle,
    runtime: State<'_, VeloVoiceRuntime>,
) -> Result<VeloVoiceStatus, String> {
    let endpoint = ensure_started(&app, &runtime)?;
    let value = tokio::task::spawn_blocking(move || request(endpoint, "status", json!({})))
        .await
        .map_err(|error| error.to_string())??;
    Ok(VeloVoiceStatus {
        ready: true,
        running: value.get("running").and_then(Value::as_bool).unwrap_or(false),
        output_folder: value.get("outputFolder").and_then(Value::as_str).map(str::to_string),
        client_type: value.get("clientType").and_then(Value::as_str).map(str::to_string),
    })
}

#[tauri::command]
pub async fn velovoice_dub(
    app: AppHandle,
    runtime: State<'_, VeloVoiceRuntime>,
    base_name: String,
    text: String,
) -> Result<VeloVoiceDubResult, String> {
    if text.trim().is_empty() {
        return Err("最终配音文本为空".into());
    }
    if base_name.trim().is_empty() {
        return Err("任务名称为空".into());
    }
    let endpoint = ensure_started(&app, &runtime)?;
    let value = tokio::task::spawn_blocking(move || {
        request(endpoint, "dub", json!({ "baseName": base_name, "text": text }))
    })
    .await
    .map_err(|error| error.to_string())??;

    let output_folder = value
        .get("outputFolder")
        .and_then(Value::as_str)
        .ok_or_else(|| "VeloVoice 未返回输出目录".to_string())?
        .to_string();
    let files = value
        .get("files")
        .and_then(Value::as_array)
        .map(|items| items.iter().filter_map(Value::as_str).map(str::to_string).collect())
        .unwrap_or_default();
    if files.is_empty() {
        return Err("VeloVoice 完成但没有返回音频文件".into());
    }
    Ok(VeloVoiceDubResult { output_folder, files })
}

#[derive(Clone)]
struct Endpoint {
    port: u16,
    token: String,
}

fn ensure_started(app: &AppHandle, runtime: &State<'_, VeloVoiceRuntime>) -> Result<Endpoint, String> {
    let mut state = runtime.inner.lock().map_err(|_| "VeloVoice 状态锁异常".to_string())?;
    if let Some(child) = state.child.as_mut() {
        if child.try_wait().map_err(|error| error.to_string())?.is_none() && state.port != 0 && !state.token.is_empty() {
            let endpoint = Endpoint { port: state.port, token: state.token.clone() };
            if request(endpoint.clone(), "ping", json!({})).is_ok() {
                return Ok(endpoint);
            }
        }
    }
    if let Some(mut old) = state.child.take() {
        let _ = old.kill();
        let _ = old.wait();
    }

    let install_root = locate_install_root(app)?;
    let java = locate_java(app, &install_root)?;
    let jar = locate_sidecar_jar(app, &install_root)?;
    let token = random_token();
    let user_data = app.path().app_local_data_dir().map_err(|error| error.to_string())?.join("VeloVoice");
    std::fs::create_dir_all(&user_data).map_err(|error| format!("创建 VeloVoice 用户目录失败：{error}"))?;
    let config_file = legacy_or_local_config(&install_root, &user_data);
    if let Some(parent) = config_file.parent() { let _ = std::fs::create_dir_all(parent); }
    let dependencies = install_root.join("Dependencies");
    let mut command = Command::new(&java);
    command
        .arg(format!("-Drewrite.dubbing.velovoice.config={}", config_file.display()))
        .arg(format!("-Djava.library.path={}", dependencies.display()))
        .arg("-cp")
        .arg(&jar)
        .arg("mai_onsyn.RewriteDubbingV2.velo.VeloVoiceSidecarLauncher")
        .env("REWRITE_VELOVOICE_TOKEN", &token)
        .env("REWRITE_VELOVOICE_PORT", "0")
        .current_dir(&user_data)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    #[cfg(windows)]
    command.creation_flags(CREATE_NO_WINDOW);

    let mut child = command.spawn().map_err(|error| format!("启动 VeloVoice 失败：{error}"))?;
    let stdout = child.stdout.take().ok_or_else(|| "无法读取 VeloVoice 启动状态".to_string())?;
    if let Some(stderr) = child.stderr.take() {
        std::thread::spawn(move || {
            let reader = BufReader::new(stderr);
            for line in reader.lines().map_while(Result::ok) {
                eprintln!("[VeloVoice] {line}");
            }
        });
    }
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let mut reader = BufReader::new(stdout);
        let mut first = String::new();
        match reader.read_line(&mut first) {
            Ok(_) => {
                let _ = tx.send(Ok(first));
                for line in reader.lines().map_while(Result::ok) {
                    eprintln!("[VeloVoice] {line}");
                }
            }
            Err(error) => {
                let _ = tx.send(Err(error));
            }
        }
    });
    let line = rx
        .recv_timeout(Duration::from_secs(20))
        .map_err(|_| "VeloVoice 启动超时".to_string())?
        .map_err(|error| format!("读取 VeloVoice 启动状态失败：{error}"))?;
    let port = line
        .trim()
        .strip_prefix("VELOVOICE_BRIDGE_READY ")
        .and_then(|value| value.parse::<u16>().ok())
        .filter(|port| *port > 0)
        .ok_or_else(|| format!("VeloVoice 启动状态无效：{}", line.trim()))?;

    let endpoint = Endpoint { port, token: token.clone() };
    request(endpoint.clone(), "ping", json!({})).map_err(|error| {
        let _ = child.kill();
        error
    })?;
    state.child = Some(child);
    state.token = token;
    state.port = port;
    Ok(endpoint)
}

fn locate_install_root(app: &AppHandle) -> Result<PathBuf, String> {
    let mut candidates = Vec::new();
    if let Ok(exe) = std::env::current_exe() {
        if let Some(root) = exe.parent() {
            candidates.push(root.to_path_buf());
            if let Some(parent) = root.parent() { candidates.push(parent.to_path_buf()); }
        }
    }
    if let Ok(resource_dir) = app.path().resource_dir() {
        candidates.push(resource_dir.clone());
        if let Some(parent) = resource_dir.parent() { candidates.push(parent.to_path_buf()); }
    }
    candidates.into_iter().find(|root| root.join("Runtime/bin/java.exe").is_file())
        .ok_or_else(|| "未找到 RewriteDubbing V2 运行资源（缺少 Runtime）".to_string())
}

fn legacy_or_local_config(install_root: &Path, local_root: &Path) -> PathBuf {
    let local = local_root.join("config.json");
    let mut candidates = vec![
        install_root.join("UserData/Config/VeloVoice/config.json"),
        install_root.join("Config/VeloVoice/config.json"),
    ];
    if let Ok(exe) = std::env::current_exe() {
        if let Some(root) = exe.parent() {
            candidates.push(root.join("UserData/Config/VeloVoice/config.json"));
            if let Some(parent) = root.parent() {
                candidates.push(parent.join("UserData/Config/VeloVoice/config.json"));
            }
        }
    }
    if !local.is_file() {
        if let Some(old) = candidates.into_iter().find(|path| path.is_file()) {
            let _ = std::fs::copy(old, &local);
        }
    }
    local
}

fn locate_java(app: &AppHandle, install_root: &Path) -> Result<PathBuf, String> {
    let mut candidates = vec![
        install_root.join("Runtime/bin/java.exe"),
        install_root.join("Runtime/bin/javaw.exe"),
    ];
    if let Ok(resource_dir) = app.path().resource_dir() {
        candidates.push(resource_dir.join("Runtime/bin/java.exe"));
        candidates.push(resource_dir.join("Runtime/bin/javaw.exe"));
    }
    if let Ok(java_home) = std::env::var("JAVA_HOME") {
        candidates.push(Path::new(&java_home).join("bin/java.exe"));
        candidates.push(Path::new(&java_home).join("bin/java"));
    }
    candidates.into_iter().find(|path| path.is_file()).ok_or_else(|| {
        "未找到 Java Runtime。V2 首次安装请保留原 RewriteDubbing/Runtime，或安装完整依赖包。".to_string()
    })
}

fn locate_sidecar_jar(app: &AppHandle, install_root: &Path) -> Result<PathBuf, String> {
    let mut candidates = vec![install_root.join("Tools/VeloVoiceBridge/RewriteDubbing-V2-VeloVoice-Sidecar.jar")];
    if let Ok(resource_dir) = app.path().resource_dir() {
        candidates.push(resource_dir.join("RewriteDubbing-V2-VeloVoice-Sidecar.jar"));
        candidates.push(resource_dir.join("v2-resources/RewriteDubbing-V2-VeloVoice-Sidecar.jar"));
    }
    if let Ok(exe) = std::env::current_exe() {
        if let Some(root) = exe.parent() {
            candidates.push(root.join("Tools/VeloVoiceBridge/RewriteDubbing-V2-VeloVoice-Sidecar.jar"));
            candidates.push(root.join("RewriteDubbing-V2-VeloVoice-Sidecar.jar"));
        }
    }
    candidates.into_iter().find(|path| path.is_file()).ok_or_else(|| "缺少 VeloVoice V2 bridge JAR".to_string())
}

fn request(endpoint: Endpoint, action: &str, payload: Value) -> Result<Value, String> {
    let addr = ("127.0.0.1", endpoint.port)
        .to_socket_addrs()
        .map_err(|error| error.to_string())?
        .next()
        .ok_or_else(|| "无效的 VeloVoice 本地地址".to_string())?;
    let stream = TcpStream::connect_timeout(&addr, Duration::from_secs(5))
        .map_err(|error| format!("连接 VeloVoice 失败：{error}"))?;
    stream.set_read_timeout(Some(Duration::from_secs(70 * 60))).map_err(|error| error.to_string())?;
    stream.set_write_timeout(Some(Duration::from_secs(10))).map_err(|error| error.to_string())?;
    let mut request = payload.as_object().cloned().unwrap_or_default();
    request.insert("token".into(), Value::String(endpoint.token));
    request.insert("action".into(), Value::String(action.to_string()));

    let mut writer = BufWriter::new(stream.try_clone().map_err(|error| error.to_string())?);
    serde_json::to_writer(&mut writer, &Value::Object(request)).map_err(|error| error.to_string())?;
    writer.write_all(b"\n").map_err(|error| error.to_string())?;
    writer.flush().map_err(|error| error.to_string())?;

    let mut reader = BufReader::new(stream);
    let mut line = String::new();
    reader.read_line(&mut line).map_err(|error| format!("读取 VeloVoice 返回失败：{error}"))?;
    let value: Value = serde_json::from_str(&line).map_err(|error| format!("VeloVoice 返回格式错误：{error}"))?;
    if value.get("ok").and_then(Value::as_bool) != Some(true) {
        return Err(value.get("message").and_then(Value::as_str).unwrap_or("VeloVoice 执行失败").to_string());
    }
    Ok(value)
}

fn random_token() -> String {
    let mut bytes = [0u8; 32];
    OsRng.fill_bytes(&mut bytes);
    let mut out = String::with_capacity(64);
    for byte in bytes {
        use std::fmt::Write as _;
        let _ = write!(&mut out, "{byte:02x}");
    }
    out
}
