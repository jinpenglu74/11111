from pathlib import Path
import json,re,subprocess,sys,zipfile,hashlib
ROOT=Path(__file__).resolve().parents[1]
SIDE=ROOT.parent/'v2-sidecar'/'RewriteDubbing-V2-VeloVoice-Sidecar.jar'
passed=0

def ok(name,cond,detail=''):
    global passed
    if not cond:
        raise AssertionError(f'{name} FAILED {detail}')
    passed+=1
    print(f'PASS {passed:02d}: {name}')

adapter=json.loads((ROOT/'adapters/meta.json').read_text(encoding='utf-8'))
ok('DeepSeek adapter keeps compatibility provider id',adapter['provider']=='meta')
ok('DeepSeek adapter app scope',adapter['urls']['app']=='https://chat.deepseek.com' and adapter['urls']['match']==['chat.deepseek.com/*'])
ok('DeepSeek adapter input selectors',adapter['inputSelectors'][0]=='textarea#chat-input')
ok('DeepSeek adapter assistant selector',any('ds-assistant-message-main-content' in x for x in adapter['responseSelectors']))
ok('DeepSeek adapter loading detector',any('ds-message-loading' in (x if isinstance(x,str) else x.get('selector','')) for x in adapter['thinkingDetectors']))
ok('DeepSeek sends by Enter not generic click',adapter['sendStrategy']=='enter')

pipeline=(ROOT/'src/workflow/rewritePipeline.ts').read_text(encoding='utf-8')
ok('Pipeline never creates/switches session','newSession' not in pipeline and 'provider_new_session' not in pipeline)
seq=["REWRITE_DEEPSEEK_PROVIDER, 'deepseek-first'","REWRITE_CHATGPT_PROVIDER, 'chatgpt-second'","REWRITE_DEEPSEEK_PROVIDER, 'deepseek-final'"]
pos=[pipeline.index(x) for x in seq]
ok('Fixed DeepSeek -> ChatGPT -> DeepSeek order',pos==sorted(pos))
ok('First raw handoff preserved',"chatgpt-second', '2/3 ChatGPT 第二轮处理中…', first" in pipeline)
ok('Second raw handoff preserved',"deepseek-final', '3/3 DeepSeek 最终轮处理中…', second" in pipeline)
ok('No trim/reformat on returned value','return response;' in pipeline and 'return response.trim' not in pipeline)
ok('Blank reply fails closed','response.trim().length === 0' in pipeline)
ok('Provider readiness gate present','assertRewriteProvidersReady' in pipeline and 'isSendable' in pipeline)
ok('Failure stops active provider','hooks.stop(activeProvider)' in pipeline)

panel=(ROOT/'src/ui/RewriteDubbingPanel.tsx').read_text(encoding='utf-8')
ok('Task center sequentially awaits pipeline','await runRewritePipeline' in panel)
ok('Task center awaits VeloVoice before completion','await host.velovoice.dub' in panel)
ok('Batch fails closed','break; // fail closed' in panel)
ok('Final text uses pre-wrap','whitespace-pre-wrap' in panel)
ok('New run clears visible logs','setLogs([])' in panel)

rust=(ROOT/'src-tauri/src/velovoice.rs').read_text(encoding='utf-8')
ok('VeloVoice bridge is loopback only','127.0.0.1' in rust)
ok('VeloVoice bridge uses random token','OsRng.fill_bytes' in rust and 'REWRITE_VELOVOICE_TOKEN' in rust)
ok('VeloVoice dub rejects blank final text','最终配音文本为空' in rust)

zh=(ROOT/'src/i18n/zh-CN.ts').read_text(encoding='utf-8')
ok('Simplified Chinese locale exists','export const zhCN' in zh)

side_src=ROOT.parent/'v2-sidecar-src'/'RewriteDubbingV2'/'velo'
expected_sources={
    'VeloVoiceAutomation.java','VeloVoiceBridgeServer.java','VeloVoiceProtocolSelfTest.java',
    'VeloVoiceSidecarApp.java','VeloVoiceSidecarLauncher.java'
}
found_sources={x.name for x in side_src.glob('*.java')} if side_src.is_dir() else set()
ok('Isolated VeloVoice sidecar sources exist',expected_sources.issubset(found_sources),str(sorted(found_sources)))
source_text='\n'.join((side_src/name).read_text(encoding='utf-8') for name in sorted(expected_sources))
ok('Sidecar source excludes old RewriteDubbing AI/browser/task imports','mai_onsyn.RewriteDubbing.' not in source_text)

if SIDE.is_file():
    with zipfile.ZipFile(SIDE) as z:
        names=z.namelist()
        old=[n for n in names if n.startswith('mai_onsyn/RewriteDubbing/') and not n.endswith('/')]
        new_classes=[n for n in names if n.startswith('mai_onsyn/RewriteDubbingV2/')]
        ok('Built sidecar contains V2 bridge classes',len(new_classes)>=5,str(new_classes))
        ok('Built sidecar excludes every old RewriteDubbing class',len(old)==0,str(old[:10]))
    sha=hashlib.sha256(SIDE.read_bytes()).hexdigest()
    print('SIDE_SHA256='+sha)
else:
    print('SIDE_SHA256=NOT_BUILT_YET')
print(f'ALL_PASS {passed}/{passed}')
