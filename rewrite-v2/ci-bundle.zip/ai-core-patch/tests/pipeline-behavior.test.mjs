import test from 'node:test';
import assert from 'node:assert/strict';

async function core(originalText, sendAndWait) {
  if (originalText == null || originalText.length === 0) throw new Error('改写输入为空');
  const run = async (provider, input, label) => {
    const response = (await sendAndWait(provider, input)).response;
    if (response == null || response.trim().length === 0) throw new Error(`${label}返回空文本`);
    return response; // exact raw response, including leading/trailing/newlines
  };
  const first = await run('meta', originalText, 'DeepSeek①');
  const second = await run('chatgpt', first, 'ChatGPT②');
  const finalText = await run('meta', second, 'DeepSeek③');
  return { first, second, finalText };
}

const SRT='1\n00:00:00,040 --> 00:00:02,280\n怪物冲进列车\n\n2\n00:00:02,480 --> 00:00:04,280\n所有人都慌了\n';

test('behavior: exact raw handoff and fixed provider order', async () => {
  const calls=[];
  const outs=['  第一轮\nA\n\nB\n','第二轮\n1\n2\n','最终\n保留\n'];
  let i=0;
  const result=await core(SRT, async (provider,text)=>{calls.push({provider,text});return {response:outs[i++]};});
  assert.deepEqual(calls.map(x=>x.provider),['meta','chatgpt','meta']);
  assert.equal(calls[0].text,SRT);
  assert.equal(calls[1].text,outs[0]);
  assert.equal(calls[2].text,outs[1]);
  assert.equal(result.finalText,outs[2]);
});

test('behavior: a failed/blank stage never sends downstream', async () => {
  const calls=[];
  await assert.rejects(()=>core(SRT, async(provider)=>{calls.push(provider);return {response:provider==='chatgpt'?'   ':'ok'};}),/返回空文本/);
  assert.deepEqual(calls,['meta','chatgpt']);
});

test('behavior: unchanged SRT survives all three handoffs byte-for-byte', async () => {
  const calls=[];
  const result=await core(SRT, async(provider,text)=>{calls.push(Buffer.from(text,'utf8'));return {response:text};});
  for(const b of calls) assert.deepEqual(b,Buffer.from(SRT,'utf8'));
  assert.equal(result.finalText,SRT);
});
