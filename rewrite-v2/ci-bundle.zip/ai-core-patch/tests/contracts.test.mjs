import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

const adapter = JSON.parse(read('adapters/meta.json'));
const pipeline = read('src/workflow/rewritePipeline.ts');
const panel = read('src/ui/RewriteDubbingPanel.tsx');
const rust = read('src-tauri/src/velovoice.rs');
const patcher = read('apply_v2_core_patch.py');
const zhCN = read('src/i18n/zh-CN.ts');

test('DeepSeek bundled adapter is strictly scoped to chat.deepseek.com', () => {
  assert.equal(adapter.provider, 'meta');
  assert.equal(adapter.displayName, 'DeepSeek');
  assert.equal(new URL(adapter.urls.app).host, 'chat.deepseek.com');
  assert.deepEqual(adapter.urls.match, ['chat.deepseek.com/*']);
  assert.deepEqual(adapter.urls.ssoMatch, []);
  assert.ok(adapter.inputSelectors.includes('textarea#chat-input'));
  assert.ok(adapter.responseSelectors.includes('div.ds-assistant-message-main-content'));
  assert.ok(adapter.thinkingDetectors.includes('.ds-message-loading'));
  assert.equal(adapter.sendStrategy, 'enter');
});

test('rewrite pipeline uses fixed DeepSeek -> ChatGPT -> DeepSeek sequence', () => {
  const first = pipeline.indexOf("REWRITE_DEEPSEEK_PROVIDER, 'deepseek-first'");
  const second = pipeline.indexOf("REWRITE_CHATGPT_PROVIDER, 'chatgpt-second'");
  const third = pipeline.indexOf("REWRITE_DEEPSEEK_PROVIDER, 'deepseek-final'");
  assert.ok(first >= 0 && second > first && third > second);
  assert.match(pipeline, /const second = await runStage\([^\n]+, first\);/);
  assert.match(pipeline, /const finalText = await runStage\([^\n]+, second\);/);
});

test('rewrite pipeline never creates or switches AI sessions and preserves raw responses', () => {
  assert.doesNotMatch(pipeline, /newSession|provider_new_session|ensureFreshProviderSessions/);
  assert.match(pipeline, /return response;/);
  assert.doesNotMatch(pipeline, /return response\.trim\(\)/);
  assert.match(pipeline, /response\.trim\(\)\.length === 0/); // blank check only
});

test('task center is batch, sequential, fail-closed, and displays final raw text verbatim', () => {
  assert.match(panel, /multiple/);
  assert.match(panel, /for \(const task of tasks\)/);
  assert.match(panel, /break; \/\/ fail closed/);
  assert.match(panel, /host\.velovoice\.dub\(task\.name, result\.deepSeekFinal\)/);
  assert.match(panel, /whitespace-pre-wrap/);
  assert.doesNotMatch(panel, /MarkdownText/);
  assert.match(panel, /软件不会新建或切换 AI 会话/);
});

test('VeloVoice bridge is loopback/token-only and reuses installed UserData/Dependencies', () => {
  assert.match(rust, /\("127\.0\.0\.1", endpoint\.port\)/);
  assert.match(rust, /OsRng\.fill_bytes/);
  assert.match(rust, /REWRITE_VELOVOICE_TOKEN/);
  assert.match(rust, /-Drewrite\.dubbing\.home=/);
  assert.match(rust, /-Djava\.library\.path=/);
  assert.match(rust, /install_root\.join\("UserData"\)/);
  assert.match(rust, /install_root\.join\("Dependencies"\)/);
  assert.match(rust, /Tools\/VeloVoiceBridge\/RewriteDubbing-V2-VeloVoice-Sidecar\.jar/);
  assert.doesNotMatch(rust, /0\.0\.0\.0|TcpListener/);
});

test('patch makes DeepSeek active by default and Grok standby', () => {
  assert.match(patcher, /DOCK_SLOT_PROVIDERS = \['chatgpt', 'claude', 'gemini', 'meta'\]/);
  assert.match(patcher, /DEFAULT_STANDBY_PROVIDER: AIProvider = 'grok'/);
  assert.match(patcher, /rightBottom: 'meta'/);
});

test('Simplified Chinese is first-class and default in the V2 patch', () => {
  assert.match(patcher, /'zh-CN'/);
  assert.match(patcher, /language: 'zh-CN'/);
  assert.match(patcher, /Simplified Chinese \(zh-CN\)/);
  assert.match(patcher, /new Set<Locale>\(\['en', 'zh-CN', 'zh-TW', 'ja', 'de'\]\)/);
  assert.match(zhCN, /export const zhCN/);
  assert.match(zhCN, /'設定', '设置'/);
});

test('patch exposes only a local VeloVoice command surface to the control pane', () => {
  assert.match(patcher, /velovoice_start/);
  assert.match(patcher, /velovoice_status/);
  assert.match(patcher, /velovoice_show/);
  assert.match(patcher, /velovoice_dub/);
  assert.doesNotMatch(panel, /TTSEngine|VoiceRate|VoiceVolume|VoicePitch|SelectedModel|Thread/);
});

test('old RewriteDubbing browser automation is not copied by the V2 patch kit', () => {
  const all = [];
  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(p); else all.push(path.relative(root, p));
    }
  };
  walk(root);
  const joined = all.join('\n').toLowerCase();
  assert.doesNotMatch(joined, /chatgpt-ui-host|desktop-bridge|playwright|browserextension|uia/);
});
