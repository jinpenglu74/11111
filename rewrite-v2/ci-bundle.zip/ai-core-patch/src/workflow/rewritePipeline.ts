import type { AIProvider, ProviderState } from '../../shared/types';
import { AI_PROVIDERS } from '../../shared/constants';
import { host } from '../host';
import { isSendable } from './sendability';
import { providerResponseError } from './providerResponse';
import { sendAndWait } from './sendAndWait';
import { sendWorkflowStatus } from './events';

/**
 * Internal compatibility note: Multi-AI Chat v1.9.6 has five fixed provider IDs.
 * V2 keeps the fifth ID (`meta`) to preserve the mature host/webview/security code,
 * but its bundled adapter, URL scope and visible label are DeepSeek.
 */
export const REWRITE_DEEPSEEK_PROVIDER: AIProvider = 'meta';
export const REWRITE_CHATGPT_PROVIDER: AIProvider = 'chatgpt';
export const REWRITE_REQUIRED_PROVIDERS = [REWRITE_DEEPSEEK_PROVIDER, REWRITE_CHATGPT_PROVIDER] as const;

export type RewriteStage = 'deepseek-first' | 'chatgpt-second' | 'deepseek-final';

export interface RewritePipelineResult {
  deepSeekFirst: string;
  chatGptSecond: string;
  deepSeekFinal: string;
}

export interface RewritePipelineHooks {
  connectionsGet: () => Promise<ProviderState[]>;
  sendAndWait: (provider: AIProvider, text: string) => Promise<{ response: string; turn: number }>;
  stop: (provider: AIProvider) => Promise<void>;
  status: (text: string) => void;
}

export interface RewritePipelineOptions {
  signal?: AbortSignal;
  waitIfPaused?: () => Promise<void>;
  onStage?: (stage: RewriteStage, phase: 'begin' | 'done', text: string) => void;
}

const productionHooks: RewritePipelineHooks = {
  connectionsGet: host.connections.get,
  sendAndWait,
  stop: host.provider.stop,
  status: sendWorkflowStatus,
};

/**
 * Fixed V2 sequence.  This function NEVER creates or changes a provider session.
 * It sends into whatever DeepSeek / ChatGPT conversation is already selected in
 * each embedded WebView.  Every handoff uses the exact raw response string.
 */
export async function runRewritePipeline(
  originalText: string,
  options: RewritePipelineOptions = {},
  hooks: RewritePipelineHooks = productionHooks,
): Promise<RewritePipelineResult> {
  if (originalText == null || originalText.length === 0) throw new Error('改写输入为空');

  await assertRewriteProvidersReady(hooks);
  let activeProvider: AIProvider | undefined;
  try {
    const runStage = async (provider: AIProvider, stage: RewriteStage, label: string, input: string): Promise<string> => {
      await options.waitIfPaused?.();
      assertNotAborted(options.signal);
      activeProvider = provider;
      hooks.status(label);
      options.onStage?.(stage, 'begin', input);
      const response = requireUsableResponse(provider, (await hooks.sendAndWait(provider, input)).response, label);
      assertNotAborted(options.signal);
      options.onStage?.(stage, 'done', response);
      return response;
    };

    const first = await runStage(REWRITE_DEEPSEEK_PROVIDER, 'deepseek-first', '1/3 DeepSeek 第一轮处理中…', originalText);
    // Intentionally pass the exact returned string. Do not trim/Markdown-render/reformat it.
    const second = await runStage(REWRITE_CHATGPT_PROVIDER, 'chatgpt-second', '2/3 ChatGPT 第二轮处理中…', first);
    const finalText = await runStage(REWRITE_DEEPSEEK_PROVIDER, 'deepseek-final', '3/3 DeepSeek 最终轮处理中…', second);

    hooks.status('');
    return { deepSeekFirst: first, chatGptSecond: second, deepSeekFinal: finalText };
  } catch (error) {
    hooks.status('');
    if (activeProvider) await hooks.stop(activeProvider).catch(() => undefined);
    throw error;
  }
}

async function assertRewriteProvidersReady(hooks: RewritePipelineHooks): Promise<void> {
  const snapshot = await hooks.connectionsGet();
  const byProvider = new Map<AIProvider, ProviderState>(snapshot.map((state) => [state.provider, state]));
  const unavailable = REWRITE_REQUIRED_PROVIDERS.filter((provider) => !isSendable(byProvider.get(provider) ?? missingState(provider)));
  if (unavailable.length === 0) return;
  const names = unavailable.map((provider) => AI_PROVIDERS[provider].name).join('、');
  throw new Error(`改写流程无法开始：${names} 尚未登录或未就绪`);
}

function requireUsableResponse(provider: AIProvider, response: string, stage: string): string {
  const providerError = providerResponseError(provider, response);
  if (providerError) throw providerError;
  // Preserve all response whitespace and line breaks. trim() is ONLY the blank check.
  if (response == null || response.trim().length === 0) throw new Error(`${stage}返回空文本，流程已停止`);
  return response;
}

function assertNotAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw signal.reason instanceof Error ? signal.reason : new Error('任务已停止');
}

function missingState(provider: AIProvider): ProviderState {
  return { provider, webview: 'none', dom: 'unknown', login: 'unknown', thinking: false, lastStatusAt: 0 };
}
