import { useEffect, useMemo, useRef, useState } from 'react';
import { host } from '../host';
import { runRewritePipeline, type RewriteStage } from '../workflow/rewritePipeline';

type TaskStatus = '等待' | '运行中' | '已暂停' | '失败' | '完成';
interface RewriteTask {
  id: string;
  name: string;
  raw: string;
  status: TaskStatus;
  stage: string;
  startedAt?: number;
  elapsedMs?: number;
  finalText?: string;
  audioFiles?: string[];
  error?: string;
}

const stageLabel: Record<RewriteStage, string> = {
  'deepseek-first': 'DeepSeek①',
  'chatgpt-second': 'ChatGPT②',
  'deepseek-final': 'DeepSeek③',
};

function elapsedText(ms?: number): string {
  if (ms == null || ms < 0) return '--';
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h > 0 ? `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

async function sha256Text(text: string): Promise<string> {
  const data = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest)).map((value) => value.toString(16).padStart(2, '0')).join('');
}

export function RewriteDubbingPanel({
  disabled = false,
  onRunningChange,
}: {
  disabled?: boolean;
  onRunningChange?: (running: boolean) => void;
}) {
  const [tasks, setTasks] = useState<RewriteTask[]>([]);
  const [running, setRunning] = useState(false);
  const [paused, setPaused] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [selectedId, setSelectedId] = useState<string>();
  const [clock, setClock] = useState(() => Date.now());
  const abortRef = useRef<AbortController>();
  const pausedRef = useRef(false);
  pausedRef.current = paused;

  useEffect(() => {
    onRunningChange?.(running);
    return () => onRunningChange?.(false);
  }, [onRunningChange, running]);

  useEffect(() => {
    if (!running) return undefined;
    const timer = window.setInterval(() => setClock(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [running]);

  const selected = useMemo(() => tasks.find((task) => task.id === selectedId) ?? tasks[0], [tasks, selectedId]);

  const log = (message: string) => {
    const stamp = new Date().toLocaleTimeString('zh-CN', { hour12: false });
    setLogs((current) => [...current.slice(-799), `${stamp} ${message}`]);
  };

  const logTextEvidence = async (taskName: string, stage: string, kind: '输入' | '返回', text: string) => {
    const hash = await sha256Text(text);
    log(`[task=${taskName}] [stage=${stage}] ${kind} chars=${text.length} sha256=${hash}`);
  };

  const addFiles = async (files: FileList | null) => {
    if (!files?.length || running || disabled) return;
    const next: RewriteTask[] = [];
    for (const file of Array.from(files)) {
      if (!file.name.toLowerCase().endsWith('.srt')) continue;
      const raw = await file.text();
      next.push({ id: crypto.randomUUID(), name: file.name, raw, status: '等待', stage: '等待' });
    }
    if (!next.length) return;
    setTasks((current) => [...current, ...next]);
    setSelectedId((current) => current ?? next[0].id);
    log(`已添加 ${next.length} 个 SRT；队列总数=${tasks.length + next.length}`);
  };

  const patchTask = (id: string, patch: Partial<RewriteTask>) => {
    setTasks((current) => current.map((task) => (task.id === id ? { ...task, ...patch } : task)));
  };

  const waitIfPaused = async () => {
    while (pausedRef.current) await new Promise((resolve) => setTimeout(resolve, 200));
  };

  const start = async () => {
    if (running || disabled || tasks.length === 0) return;
    const controller = new AbortController();
    abortRef.current = controller;
    setRunning(true);
    setPaused(false);
    setLogs([]);
    log('开始新的批量任务；会话策略=保持当前 DeepSeek/ChatGPT 网页会话；禁止自动新建/切换');
    try {
      for (const task of tasks) {
        if (controller.signal.aborted) break;
        if (task.status === '完成') continue;
        await waitIfPaused();
        const startedAt = Date.now();
        setClock(startedAt);
        patchTask(task.id, { status: '运行中', stage: '准备', startedAt, error: undefined, audioFiles: undefined, elapsedMs: undefined });
        setSelectedId(task.id);
        log(`[task=${task.name}] 开始；sourceChars=${task.raw.length}`);
        await logTextEvidence(task.name, 'SRT', '输入', task.raw);
        try {
          const result = await runRewritePipeline(task.raw, {
            signal: controller.signal,
            waitIfPaused,
            onStage: (stage, phase, text) => {
              const label = stageLabel[stage];
              patchTask(task.id, { stage: label, status: pausedRef.current ? '已暂停' : '运行中' });
              if (phase === 'begin') {
                log(`[task=${task.name}] [stage=${label}] SEND begin provider=${stage.includes('chatgpt') ? 'ChatGPT' : 'DeepSeek'} chars=${text.length}`);
                void logTextEvidence(task.name, label, '输入', text);
              } else {
                log(`[task=${task.name}] [stage=${label}] RESPONSE_DONE chars=${text.length}`);
                void logTextEvidence(task.name, label, '返回', text);
              }
            },
          });
          if (controller.signal.aborted) throw new Error('任务已停止');
          patchTask(task.id, { stage: 'VeloVoice', finalText: result.deepSeekFinal });
          log(`[task=${task.name}] [stage=VeloVoice] 提交最终文本 chars=${result.deepSeekFinal.length}`);
          await logTextEvidence(task.name, 'VeloVoice', '输入', result.deepSeekFinal);
          const audio = await host.velovoice.dub(task.name, result.deepSeekFinal);
          patchTask(task.id, {
            status: '完成',
            stage: '完成',
            finalText: result.deepSeekFinal,
            audioFiles: audio.files,
            elapsedMs: Date.now() - startedAt,
          });
          log(`[task=${task.name}] [stage=VeloVoice] 完成 output=${audio.outputFolder} files=${audio.files.length}`);
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          patchTask(task.id, { status: '失败', stage: '失败', error: message, elapsedMs: Date.now() - startedAt });
          log(`[task=${task.name}] 失败；error=${message}`);
          break; // fail closed: never continue the next SRT after a failed stage.
        }
      }
    } finally {
      setRunning(false);
      setPaused(false);
      abortRef.current = undefined;
      log('批量任务结束');
    }
  };

  const stop = async () => {
    abortRef.current?.abort(new Error('用户停止任务'));
    setPaused(false);
    log('收到停止请求；当前 Provider 将由流水线执行停止清理');
  };

  const togglePause = () => {
    if (!running) return;
    setPaused((value) => {
      const next = !value;
      log(next ? '已请求暂停；当前 AI 回复结束后停在阶段边界' : '继续执行');
      return next;
    });
  };

  const copyLogs = async () => {
    await navigator.clipboard.writeText(logs.join('\n'));
  };

  const taskElapsed = (task: RewriteTask): number | undefined =>
    task.elapsedMs ?? (task.startedAt && (task.status === '运行中' || task.status === '已暂停') ? clock - task.startedAt : undefined);

  return (
    <section className="mb-3 rounded-lg border border-sky-200 bg-white p-3 shadow-sm dark:border-sky-900 dark:bg-zinc-950">
      <div className="flex flex-wrap items-center gap-2">
        <div className="mr-auto">
          <div className="text-sm font-semibold">改写配音任务中心</div>
          <div className="mt-0.5 text-xs text-zinc-500">DeepSeek① → ChatGPT② → DeepSeek③ → VeloVoice；沿用当前网页会话</div>
        </div>
        <label className={`rounded border border-zinc-300 px-2 py-1 text-xs dark:border-zinc-700 ${running || disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer hover:bg-zinc-50 dark:hover:bg-zinc-900'}`}>
          添加 SRT
          <input className="hidden" type="file" accept=".srt,text/plain" multiple disabled={running || disabled} onChange={(event) => void addFiles(event.currentTarget.files)} />
        </label>
        <button className="rounded bg-sky-600 px-3 py-1 text-xs font-medium text-white disabled:opacity-50" disabled={running || disabled || tasks.length === 0} onClick={() => void start()}>开始</button>
        <button className="rounded border border-zinc-300 px-3 py-1 text-xs disabled:opacity-50 dark:border-zinc-700" disabled={!running} onClick={togglePause}>{paused ? '继续' : '暂停'}</button>
        <button className="rounded border border-red-300 px-3 py-1 text-xs text-red-700 disabled:opacity-50 dark:border-red-900 dark:text-red-300" disabled={!running} onClick={() => void stop()}>停止</button>
        <button className="rounded border border-zinc-300 px-3 py-1 text-xs dark:border-zinc-700" disabled={running} onClick={() => void host.velovoice.show()}>VeloVoice</button>
      </div>

      <div className="mt-3 max-h-44 overflow-auto rounded border border-zinc-200 dark:border-zinc-800">
        {tasks.length === 0 ? <div className="p-3 text-xs text-zinc-500">添加 SRT 后即可开始。软件不会新建或切换 AI 会话。</div> : (
          <>
            <div className="grid grid-cols-[minmax(0,1fr)_90px_70px_70px] gap-2 border-b border-zinc-200 bg-zinc-50 px-2 py-1 text-[11px] font-medium text-zinc-500 dark:border-zinc-800 dark:bg-zinc-900"><span>文件名</span><span>当前步骤</span><span>状态</span><span>总用时</span></div>
            {tasks.map((task) => (
              <button key={task.id} type="button" onClick={() => setSelectedId(task.id)} className={`grid w-full grid-cols-[minmax(0,1fr)_90px_70px_70px] gap-2 border-b border-zinc-100 px-2 py-1.5 text-left text-xs last:border-b-0 dark:border-zinc-900 ${selected?.id === task.id ? 'bg-sky-50 dark:bg-sky-950/30' : ''}`}>
                <span className="truncate">{task.name}</span><span>{task.stage}</span><span>{task.status}</span><span>{elapsedText(taskElapsed(task))}</span>
              </button>
            ))}
          </>
        )}
      </div>

      {selected ? (
        <div className="mt-3 grid gap-2 lg:grid-cols-2">
          <div className="min-h-24 max-h-52 overflow-auto rounded border border-zinc-200 p-2 text-xs dark:border-zinc-800">
            <div className="mb-1 flex items-center justify-between gap-2"><span className="font-medium">最终文案</span><span className="text-zinc-500">原始换行显示</span></div>
            <div className="whitespace-pre-wrap font-mono">{selected.finalText ?? selected.error ?? '等待第三轮结果…'}</div>
          </div>
          <div className="min-h-24 max-h-52 overflow-auto rounded border border-zinc-200 p-2 text-xs dark:border-zinc-800">
            <div className="mb-1 flex items-center justify-between gap-2"><span className="font-medium">运行日志</span><span className="flex gap-1"><button className="border px-1.5 py-0.5 dark:border-zinc-700" onClick={() => void copyLogs()}>复制日志</button><button className="border px-1.5 py-0.5 dark:border-zinc-700" disabled={running} onClick={() => setLogs([])}>清空界面日志</button></span></div>
            <div className="whitespace-pre-wrap font-mono">{logs.join('\n') || '等待运行…'}</div>
          </div>
        </div>
      ) : null}
    </section>
  );
}
