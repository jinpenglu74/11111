import { describe, expect, it, vi } from 'vitest';
import type { AIProvider, ProviderState } from '../../shared/types';
import {
  REWRITE_CHATGPT_PROVIDER,
  REWRITE_DEEPSEEK_PROVIDER,
  runRewritePipeline,
  type RewritePipelineHooks,
} from '../workflow/rewritePipeline';

function readyState(provider: AIProvider): ProviderState {
  return {
    provider,
    webview: 'loaded',
    dom: 'ready',
    login: 'logged_in',
    thinking: false,
    lastStatusAt: Date.now(),
  };
}

function hooksWith(
  send: (provider: AIProvider, text: string) => Promise<{ response: string; turn: number }>,
  states: ProviderState[] = [readyState(REWRITE_DEEPSEEK_PROVIDER), readyState(REWRITE_CHATGPT_PROVIDER)],
): RewritePipelineHooks {
  return {
    connectionsGet: vi.fn(async () => states),
    sendAndWait: vi.fn(send),
    stop: vi.fn(async () => undefined),
    status: vi.fn(),
  };
}

describe('RewriteDubbing V2 fixed pipeline', () => {
  it('uses DeepSeek -> ChatGPT -> DeepSeek and preserves every raw handoff byte-for-byte', async () => {
    const original = '1\n00:00:00,040 --> 00:00:02,280\n第一行  保留双空格\n\n2\n00:00:02,480 --> 00:00:04,280\n第二行\n';
    const first = 'DS-1\n\nA  B\n00:00:00,040 --> 00:00:02,280\n';
    const second = 'GPT-2\n\nX  Y\n00:00:02,480 --> 00:00:04,280\n';
    const finalText = 'DS-3\n\nFINAL  TEXT\n';
    const calls: Array<[AIProvider, string]> = [];
    const responses = [first, second, finalText];
    const hooks = hooksWith(async (provider, text) => {
      calls.push([provider, text]);
      return { response: responses[calls.length - 1], turn: calls.length };
    });

    const result = await runRewritePipeline(original, {}, hooks);

    expect(calls).toEqual([
      [REWRITE_DEEPSEEK_PROVIDER, original],
      [REWRITE_CHATGPT_PROVIDER, first],
      [REWRITE_DEEPSEEK_PROVIDER, second],
    ]);
    expect(result).toEqual({ deepSeekFirst: first, chatGptSecond: second, deepSeekFinal: finalText });
    expect(hooks.connectionsGet).toHaveBeenCalledTimes(1);
  });

  it('fails closed at the current stage and never sends the following stage', async () => {
    const calls: AIProvider[] = [];
    const hooks = hooksWith(async (provider) => {
      calls.push(provider);
      if (calls.length === 2) throw new Error('chatgpt failed');
      return { response: 'first', turn: calls.length };
    });

    await expect(runRewritePipeline('source', {}, hooks)).rejects.toThrow('chatgpt failed');
    expect(calls).toEqual([REWRITE_DEEPSEEK_PROVIDER, REWRITE_CHATGPT_PROVIDER]);
    expect(hooks.stop).toHaveBeenCalledTimes(1);
    expect(hooks.stop).toHaveBeenCalledWith(REWRITE_CHATGPT_PROVIDER);
  });

  it('blocks before sending when either required current webview session is not ready', async () => {
    const hooks = hooksWith(async () => ({ response: 'should-not-send', turn: 1 }), [
      readyState(REWRITE_DEEPSEEK_PROVIDER),
      { ...readyState(REWRITE_CHATGPT_PROVIDER), login: 'logged_out' },
    ]);

    await expect(runRewritePipeline('source', {}, hooks)).rejects.toThrow('尚未登录或未就绪');
    expect(hooks.sendAndWait).not.toHaveBeenCalled();
  });

  it('rejects a blank provider reply without trimming or substituting stale content', async () => {
    const hooks = hooksWith(async () => ({ response: ' \n\t ', turn: 1 }));

    await expect(runRewritePipeline('source', {}, hooks)).rejects.toThrow('返回空文本');
    expect(hooks.sendAndWait).toHaveBeenCalledTimes(1);
  });
});
