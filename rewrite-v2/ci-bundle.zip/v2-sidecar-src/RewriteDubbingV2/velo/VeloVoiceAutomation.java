package mai_onsyn.RewriteDubbingV2.velo;

import javafx.application.Platform;
import mai_onsyn.AnimeFX.Utls.AXTreeItem;
import mai_onsyn.VeloVoice.FrameFactory.MainFactory;
import mai_onsyn.VeloVoice.NetWork.TTS.ResumableTTSClient;
import mai_onsyn.VeloVoice.Text.TTS;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static mai_onsyn.VeloVoice.App.Runtime.CLIENT_TYPE;
import static mai_onsyn.VeloVoice.App.Runtime.disableNaturalTTS;
import static mai_onsyn.VeloVoice.App.Runtime.isTTSRunning;

/**
 * V2's only VeloVoice automation boundary.
 *
 * It deliberately does NOT change TTS engine, voice, rate, volume, pitch,
 * thread count, or output directory.  It only writes one dedicated text item,
 * verifies an exact round-trip, then calls VeloVoice's original TTS.start().
 */
public final class VeloVoiceAutomation {
    private VeloVoiceAutomation() {}

    public record Result(Path outputFolder, List<Path> files) {}

    public static Result dub(String baseName, String text) throws Exception {
        if (text == null || text.isBlank()) throw new IOException("最终配音文本为空");
        if (baseName == null || baseName.isBlank()) throw new IOException("任务名称为空");
        if (CLIENT_TYPE == ResumableTTSClient.ClientType.NATURAL && disableNaturalTTS) {
            throw new IOException("当前电脑的 Natural TTS 已被 VeloVoice 禁用，请在 VeloVoice 页面切换其他引擎或修复 Natural TTS 环境。");
        }
        if (isTTSRunning.get()) throw new IOException("VeloVoice 当前已有配音任务正在运行，请停止后再继续自动任务");

        Prepared prepared = prepareAndVerify(safeBase(baseName), text);
        Files.createDirectories(prepared.outputFolder());
        long started = System.currentTimeMillis();
        setTtsRunningSync(true);
        try {
            TTS.start(prepared.item(), prepared.outputFolder().toFile());
            List<Path> generated = collectGenerated(prepared.outputFolder(), safeBase(baseName), started);
            if (generated.stream().noneMatch(VeloVoiceAutomation::isAudio)) {
                throw new IOException("VeloVoice 返回完成，但已设置的音频目录未发现本次 mp3/wav 产物：" + prepared.outputFolder());
            }
            return new Result(prepared.outputFolder(), generated);
        } catch (InterruptedException e) {
            if (TTS.pool != null) TTS.pool.close();
            throw e;
        } finally {
            setTtsRunningSync(false);
        }
    }

    public static String configuredOutputFolder() throws IOException, InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<Path> output = new AtomicReference<>();
        AtomicReference<Throwable> error = new AtomicReference<>();
        Platform.runLater(() -> {
            try {
                output.set(MainFactory.getConfiguredAudioSaveFolder().toPath().toAbsolutePath().normalize());
            } catch (Throwable t) {
                error.set(t);
            } finally {
                latch.countDown();
            }
        });
        if (!latch.await(5, TimeUnit.SECONDS)) throw new IOException("读取 VeloVoice 输出目录超时");
        if (error.get() != null) throw new IOException("读取 VeloVoice 输出目录失败", error.get());
        if (output.get() == null) throw new IOException("VeloVoice 未配置有效的音频保存目录");
        return output.get().toString();
    }

    private static Prepared prepareAndVerify(String base, String text) throws IOException, InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<Throwable> error = new AtomicReference<>();
        AtomicReference<AXTreeItem> item = new AtomicReference<>();
        AtomicReference<String> actual = new AtomicReference<>("");
        AtomicReference<Path> output = new AtomicReference<>();
        Platform.runLater(() -> {
            try {
                item.set(MainFactory.prepareAutomationText(base, text));
                actual.set(MainFactory.getAutomationEditorText());
                output.set(MainFactory.getConfiguredAudioSaveFolder().toPath().toAbsolutePath().normalize());
            } catch (Throwable t) {
                error.set(t);
            } finally {
                latch.countDown();
            }
        });
        if (!latch.await(15, TimeUnit.SECONDS)) throw new IOException("VeloVoice 文本写入/校验超时");
        if (error.get() != null) throw new IOException("VeloVoice 文本写入失败", error.get());
        if (item.get() == null) throw new IOException("VeloVoice 未创建当前任务文本项");
        if (!sameText(actual.get(), text)) {
            throw new IOException("VeloVoice 文本写入后读回不一致：期望 " + text.length() + " 字符，实际 " + actual.get().length() + " 字符；禁止开始配音。");
        }
        if (output.get() == null) throw new IOException("VeloVoice 未配置有效的音频保存目录");
        return new Prepared(item.get(), output.get());
    }

    private static List<Path> collectGenerated(Path outputFolder, String base, long started) throws IOException {
        if (!Files.exists(outputFolder)) return List.of();
        try (var stream = Files.walk(outputFolder)) {
            String lowerBase = base.toLowerCase();
            return stream.filter(Files::isRegularFile)
                    .filter(VeloVoiceAutomation::isAudio)
                    .filter(path -> {
                        try {
                            String name = path.getFileName().toString().toLowerCase();
                            return name.startsWith(lowerBase) && Files.getLastModifiedTime(path).toMillis() >= started - 2000;
                        } catch (IOException e) {
                            return false;
                        }
                    })
                    .sorted()
                    .toList();
        }
    }

    private static void setTtsRunningSync(boolean value) throws IOException, InterruptedException {
        if (Platform.isFxApplicationThread()) {
            isTTSRunning.set(value);
            return;
        }
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<Throwable> error = new AtomicReference<>();
        Platform.runLater(() -> {
            try {
                isTTSRunning.set(value);
            } catch (Throwable t) {
                error.set(t);
            } finally {
                latch.countDown();
            }
        });
        if (!latch.await(5, TimeUnit.SECONDS)) throw new IOException("VeloVoice 运行状态更新超时：" + (value ? "启动" : "结束"));
        if (error.get() != null) throw new IOException("VeloVoice 运行状态更新失败：" + (value ? "启动" : "结束"), error.get());
    }

    static boolean sameText(String a, String b) { return normalize(a).equals(normalize(b)); }
    static String normalize(String s) { return s == null ? "" : s.replace("\r\n", "\n").replace('\r', '\n').replace('\u00a0', ' ').trim(); }
    static boolean isAudio(Path p) { String n = p.getFileName().toString().toLowerCase(); return n.endsWith(".mp3") || n.endsWith(".wav"); }
    static String safeBase(String name) {
        String base = name.toLowerCase().endsWith(".srt") ? name.substring(0, name.length() - 4) : name;
        return base.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
    }
    private record Prepared(AXTreeItem item, Path outputFolder) {}
}
